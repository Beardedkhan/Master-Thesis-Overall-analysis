
#poisson Model for the dataset

data <- read.csv(choose.files())
y <- data$Total
x <- data[, c("Type", "Type_code", "Year", "Gender", "Age_group","State")]

X_encoded <- model.matrix(~., data = x)


#fitting the Poisson Regression model
poisson_model <- glm(y ~ ., data = data.frame(y, X_encoded), family = poisson())

#Print the model summary
summary(poisson_model)



#doing Logistic Regression to check the co-relations between the features.

library(dplyr)
library(readr)
library(caret)

data <- read.csv("Suicides in India 2001-2012.csv", stringsAsFactors = TRUE)

target <- "Total"
predictors <- c("Type", "Type_code", "Year", "Gender", "Age_group","State")

data$Total <- factor(data$Total, levels = c(0, 1))

data[predictors] <- lapply(data[predictors], as.factor)

formula <- as.formula(paste(target, "~", paste(predictors, collapse = "+")))

logit_model <- glm(formula, data = data, family = binomial)

summary(logit_model)
