library(rlang)
library(lubridate)
library(forecast)
library (ggplot2)

#Reading the dataset
data = read.csv(choose.files())
data$Year <- as.Date(paste0(data$Year, "-01-01"))

#coverting the total target variable data type into numerical for a better time series analysis
data$Total <- as.numeric(as.character(data$Total))

#creating a time series object
ts_data <- ts(data$Total, start = min(data$Year), end = max(data$Year), frequency = 1)

#exploring the time series data
plot(ts_data, main =  "Time series plot")

#Decomposing the time series data to analyze the trends over the yeas with seasonality
decomposed <- decompose(ts_data)

#performing the time series analysis
model <- auto.arima(ts_data)

#generating a forecast
forecast <- forecast(model, h = 2)
print(forecast)